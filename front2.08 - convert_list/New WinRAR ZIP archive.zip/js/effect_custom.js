$( document ).ready(function() {
	$('.list-convert').each(function(index){
		var father = $(this)
		var option = father.find('option')
		var length = father.find('option').length
		setup_HTML();
		setupData();
		function setup_HTML(){
			var index = 0
			father.find('.list-item').append(
				'<div class="item not-active" id_item="'+ option.eq((index - 3) % length).attr('id_item') +'">'+
				'	<div class="title">'+
				 		option.eq((index - 3) % length).html()+
				'	</div>'+
				'</div>'+
				'<div class="item" id_item="'+ option.eq((index - 2) % length).attr('id_item') +'">'+
				'	<div class="title">'+
				 		option.eq((index - 2) % length).html()+
				'	</div>'+
				'</div>'+
				'<div class="item" id_item="'+ option.eq((index - 1) % length).attr('id_item') +'">'+
				'	<div class="title">'+
				 		option.eq((index - 1) % length).html()+
				'	</div>'+
				'</div>'+
				'<div class="item" id_item="'+ option.eq(0).attr('id_item') +'">'+
				'	<div class="title">'+
				 		option.eq(index).html()+
				'	</div>'+
				'</div>'+
				'<div class="item" id_item="'+ option.eq((index + 1) % length).attr('id_item') +'">'+
				'	<div class="title">'+
				 		option.eq((index + 1) % length).html()+
				'	</div>'+
				'</div>'+
				'<div class="item" id_item="'+ option.eq((index + 2) % length).attr('id_item') +'">'+
				'	<div class="title">'+
				 		option.eq((index + 2) % length).html()+
				'	</div>'+
				'</div>'+
				'<div class="item not-active" id_item="'+ option.eq((index + 3) % length).attr('id_item') +'">'+
				'	<div class="title">'+
				 		option.eq((index + 3) % length).html()+
				'	</div>'+
				'</div>'
			)
			father.find('.list-item').css({
				'top': -46 + 'px'
			})
			father.find('.item').eq(3).addClass('is-select')
		}
		var index = 2;
		function prependData(index){
			father.find('.list-item').append(
				'<div class="item not-active" id_item="' + father.find('option').eq(index).attr('id_item') + '">'+
				'	<div class="title">'+
				 		father.find('option').eq(index).html()+
				'	</div>'+
				'</div>'
			)
		}
		function nextData(index){
			father.find('.list-item').prepend(
				'<div class="item not-active" id_item="' + father.find('option').eq(index).attr('id_item') + '">'+
				'	<div class="title">'+
				 		father.find('option').eq(index).html()+
				'	</div>'+
				'</div>'
			)
		}
		function setupData(){
			var data = father.find('.item').eq(3)
			father.find('.item_output').val(data.find('.title').html())
			father.find('.item_output').attr('id_item', data.attr('id_item'))
		}
		father.find('.next-control').on('click', function(){
			index--;
			father.find('.item').eq(6).remove()
			nextData(length - Math.abs(((index-4) % length) - 1))
			father.find('.item').eq(1).toggleClass('not-active')
			father.find('.item').eq(6).toggleClass('not-active')
			father.find('.item').removeClass('is-select')
			father.find('.item').eq(3).addClass('is-select')
			setupData()
		})
		father.find('.prev-control').on('click', function(){
			index++;
			prependData((index+1) % length)
			father.find('.item').eq(1).toggleClass('not-active')
			father.find('.item').eq(0).remove()
			father.find('.item').eq(5).toggleClass('not-active')
			father.find('.item').removeClass('is-select')
			father.find('.item').eq(3).addClass('is-select')
			setupData()
		})
	})
	
});