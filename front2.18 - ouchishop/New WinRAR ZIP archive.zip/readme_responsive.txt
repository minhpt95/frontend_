I-navigation > ul
responsive: khi tăng số lượng li thì ul.css({ width = tổng độ dài các phần tử li con })

.I-navigation ul{
	width: 670px;	// phần này sẽ thay đổi nếu thêm li
}